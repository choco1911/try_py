#!/usr/bin/env python

from distutils.core import setup

setup (
        name = 'recur',
        version = '1.0.2',
        py_modules = ['recur'],
        author = 'choco',
        author_email = '4oco00@gmail.com',
        url = 'http://test_py.ru',
        description = 'A simple printer of nested lists',
)
